module.exports = {
    formate: "A3",
    orientation: "portrint",
    border: "8mm",
    header: {
        height: "15mm",
        contents: '<h4 style="color:red; font-size:20; font-waight:800; align:center;"></h4> '
    },
    footer: {
        height: "20mm",
       
    }
}