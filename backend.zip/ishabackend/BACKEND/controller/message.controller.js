const MessageData = require("../module/message.modul");


exports.MessIns = async(req, res) => {
    try {
        const insertData = new MessageData({
            name: req.body.name,
            email: req.body.email,
            phoneno: req.body.phoneno,
            message: req.body.message
        })
        const saveData = await insertData.save();
        res.status(200).json({
            msg: "data insert",
            status: 200,
            data: saveData
        })
    } catch (error) {
        console.log(error);
        res.status(400).json({
            msg: "data not inserted",
            status: 400
        })
    }


}