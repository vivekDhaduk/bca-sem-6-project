const Life = require("../module/LifeIns.modul");
const lifeData = require("../module/life.modul")

exports.LifeInsUserAdd = async (req, res) => {
  try {
    const insertData = new Life({
      gender: req.body.gender,
      fullname: req.body.fullname,
      age: req.body.age,
      dateofbirth: req.body.dateofbirth,
      city: req.body.city,
      annualincome: req.body.annualincome,
      nominee: req.body.nominee,
    });
    const saveData = await insertData.save();
    res.status(200).json({
      msg: "data insert",
      status: 200,
      data: saveData,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      msg: "data not inserted",
      status: 400,
    });
  }
};
exports.lifeInsview = async (req, res) => {
  try {
    const viewData = await Life.find().sort({ date: -1 }).limit(1);
    res.status(200).json({
      message: "Record  display",
      status: 200,
      data: viewData,
    });
  } catch (error) {
    res.status(400).json({
      message: "Record not display",
      status: 400,
    });
  }
};
exports.lifeshorting = async (req, res) => {
  try {
    let annualincome = req.body.annualincome;
    // console.log("==>", annualincome);
    const showdata = await Life.findOne({ annualincome: annualincome });

    res.status(200).json({
      message: "record display",
      status: 200,
      data: showdata,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      message: "Record not display",
      status: 400,
    });
  }
};

exports.lifeCoverAcd = async (req, res) => {
    try {
      const viewData = await lifeData.find().sort({ cover: 1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };

  exports.lifeCoverDcd = async (req, res) => {
    try {
      const viewData = await lifeData.find().sort({ cover: -1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };

exports.lifeAcd = async (req, res) => {
  try {
    const viewData = await lifeData.find().sort({ primumamount: 1 });
    res.status(200).json({
      message: "Record  display",
      status: 200,
      data: viewData,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      message: "Something Went Wrong",
      status: 400,
    });
  }
};

exports.lifeDcd = async (req, res) => {
    try {
      const viewData = await lifeData.find().sort({ primumamount: -1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };