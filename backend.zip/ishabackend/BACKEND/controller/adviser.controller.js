const adviserData = require("../module/adviser.modul");
const nodemailer = require("nodemailer");

//user register
exports.adviserRegister = async(req, res) => {
    try {
        const user = new adviserData(req.body);
        await user.save();
        res.status(200).json({
            message: "adviserData  is save...",
            status: 200,
            data: user
        })
    } catch (error) {
        res.status(400).json({
            message: "adviserData  is not save..",
            status: 400
        })
    }
}

//user login
exports.adviserLogin = async(req, res) => {
    try {
        email = req.body.email;
        number = req.body.number;

        const login = await adviserData.findOne({ email });

        if (!login.tokens[0]) {
            const token = await login.generate();
        }
        res.cookie("jwt", login.tokens[0].token)
        if (email == login.email && number == login.number) {
            res.status(200).json({
                message: "adviserData successfully login...",
                status: 200
            })
        } else {
            res.status(400).json({
                message: "please enter proper detail.. for login..",
                status: 400
            })
        }
    } catch (error) {
        res.status(400).json({
            message: "adviserData not login..",
            status: 400
        })
    }
};

//user logout
exports.adviserLogout = async(req, res) => {
    try {
        req.adviser.tokens = req.adviser.tokens.filter((currele) => {
            return currele.token != req.token;
        })

        res.clearCookie("jwt");
        await req.agent.save();
        res.status(200).json({
            message: "adviser Logout Successfully",
            status: 200,
        });
    } catch (error) {
        res.status(400).json({
            message: "adviser not logout..",
            status: 400
        })
    }
}

// user can update data
exports.updateadviser = async(req, res) => {
    try {
        const _id = req.params.id;
        const updateData = await adviserData.findByIdAndUpdate(_id, req.body, { new: true });
        res.status(200).json({
            message: "Record updated",
            status: 200,
            data: updateData,
        })
    } catch (error) {
        res.status(400).json({
            message: "Record not updated..",
            status: 400
        });
    }
}
exports.viewadvisor = async(req, res) => {
    try {

        const viewData = await adviserData.find();
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.viewhelthadvisor = async(req, res) => {
    try {

        const viewData = await adviserData.findOne( { category:"Health" } );
        console.log(viewData)
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.viewlifeadvisor = async(req, res) => {
    try {

        const viewData = await adviserData.findOne( { category:"Life" } );
        console.log(viewData)
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.viewcaradvisor = async(req, res) => {
    try {

        const viewData = await adviserData.findOne( { category:"Car" } );
        console.log(viewData)
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.viewbikeadvisor = async(req, res) => {
    try {

        const viewData = await adviserData.findOne( { category:"Bike" } );
        console.log(viewData)
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.viewadvisorbyid = async(req, res) => {
    try {

        var id = req.params.id;
        const viewData = await adviserData.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }

    
};

