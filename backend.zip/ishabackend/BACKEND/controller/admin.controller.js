const adminData = require("../module/admin.modul");
const userData = require("../module/user.modul");
const jwt = require("jsonwebtoken");

// admin login
exports.adminLogin = async(req, res) => {
    try {
        const username = req.body.username;
        const password = req.body.password;

        const login = await adminData.findOne({ username });

        if (username == login.username && password == login.password) {
            if (!login.tokens[0]) {
                const token = await login.generate();
            }
            res.cookie("jwt", login.tokens[0].token);
            res.status(200).json({
                message: "Login Successfuly...",
                status: 200
            })
        } else {
            res.status(400).json({
                message: "lPlease Enter Proper Deatil Of Admin...",
                status: 400
            })
        }
    } catch (error) {
        res.status(400).json({
            message: "Admin not Login...",
            status: 400
        })
    }
};

// admin logout
exports.adminLogout = async(req, res) => {
    try {
        req.adminUser.tokens = req.adminUser.tokens.filter((currele) => {
            return currele.token != req.token;
        });

        res.clearCookie("jwt");
        await req.adminUser.save();
        res.status(201).json({
            message: "Logout Successfully...",
            status: 201,
        });
    } catch (error) {
        res.status(400).json({
            message: "Admin not Logout...",
            status: 400
        })
    }
};

// admin can view all user data
exports.viewUser = async(req, res) => {
    try {
        const viewData = await userData.find();
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });
    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};

// admin can insert all user data
exports.insertUser = async(req, res) => {
    try {
        const insertData = new userData(req.body);
        await insertData.save();
        res.status(200).json({
            message: "Record insert",
            status: 200,
            data: insertData
        })
    } catch (error) {
        res.status(400).json({
            message: "Record not insert",
            status: 400
        });
    }
};

// admin can delete all user data
exports.deleteUser = async(req, res) => {
    try {
        const _id = req.params.id;
        const deleteData = await userData.findByIdAndDelete(_id, req.body);
        res.status(200).json({
            message: "Record deleted",
            status: 200
        })
    } catch (error) {
        res.status(400).json({
            message: "Record not deleted..",
            status: 400
        });
    }
};

// admin can update all user data
exports.updateUser = async(req, res) => {
    try {
        const _id = req.params.id;
        const updateData = await userData.findByIdAndUpdate(_id, req.body, { new: true });
        res.status(200).json({
            message: "Record updated",
            status: 200,
            data: updateData,
        })
    } catch (error) {
        res.status(400).json({
            message: "Record not updated..",
            status: 400
        });
    }
}