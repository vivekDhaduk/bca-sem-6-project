const Health = require("../module/HealthIns.modul");
const Healthdata = require("../module/health.modul")
exports.HealthInsUserAdd = async(req, res) => {
    try {
        const insertData = new Health({
            gender: req.body.gender,
            fullname: req.body.fullname,
            dateofbirth: req.body.dateofbirth,
            age: req.body.age,
            city: req.body.city,
            healthproblem: req.body.healthproblem,
            annualincome: req.body.annualincome
        })
        const saveData = await insertData.save();
        res.status(200).json({
            msg: "data insert",
            status: 200,
            data: saveData
        })
    } catch (error) {
        console.log(error);
        res.status(400).json({
            msg: "data not inserted",
            status: 400
        })
    }

}
exports.HeathInsview = async(req, res) => {
    try {

        const viewData = await Health.find().sort({ "date": -1 }).limit(1)
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.healthshorting = async(req, res) => {
    try {
        let age = req.body.age;
        // console.log("==>", annualincome);
        const showdata = await Health.findOne({ age: age });

        res.status(200).json({
            message: "record display",
            status: 200,
            data: showdata
        });
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
}

exports.healthCoverAcd = async (req, res) => {
    try {
      const viewData = await Healthdata.find().sort({ cover: 1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };

  exports.healthCoverDcd = async (req, res) => {
    try {
      const viewData = await Healthdata.find().sort({ cover: -1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };

exports.healthAcd = async (req, res) => {
  try {
    const viewData = await Healthdata.find().sort({ primumamount: 1 });
    res.status(200).json({
      message: "Record  display",
      status: 200,
      data: viewData,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      message: "Something Went Wrong",
      status: 400,
    });
  }
};

exports.healthDcd = async (req, res) => {
    try {
      const viewData = await Healthdata.find().sort({ primumamount: -1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };