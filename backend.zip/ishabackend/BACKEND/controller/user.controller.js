const userData = require("../module/user.modul");
const nodemailer = require("nodemailer");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const Token = require("../module/token.modul")
const sendEmail = require("../utils/sendEmail");
const { log } = require("console");



//user register
exports.userRegister = async(req, res) => {
    try {
        const insertData = new userData({
            name: req.body.name,
            email: req.body.email,
            number: req.body.number,
            gender: req.body.gender,
            age: req.body.age,
            panno: req.body.panno,
            password: req.body.password,
            // image: req.file.filename

        });
        const email = req.body.email;
        if (email) {
            await userData.findOne({ email: email }).then((userEmail) => {
                if (!userEmail) {
                    const saveData = insertData.save();
                    res.status(201).json({
                        message: "Data saved",
                        status: 201
                    })
                } else {
                    res.status(400).json({
                        message: "Email already"
                    })
                }
            })
        } else {
            console.log("email not");
        }

    } catch (error) {
        console.log(error)
        res.status(400).json({
            message: "User data is not save..",
            status: 400
        })
    }
}

//user login
exports.userLogin = async(req, res) => {
    try {
        email = req.body.email;
        password = req.body.password;

        const login = await userData.findOne({ email });
        // console.log(login);
        var loginid =login._id
        console.log("first log " + loginid)

        if (!login.tokens[0]) {
            const token = await login.generate();
        }
        // res.cookie("jwt", login.tokens[0].token)
        if (email == login.email && password == login.password) {
            res.status(200).json({
                message: "User successfully login...",
                status: 200,
                _id:loginid,
                token: login.tokens[0].token

            })
        } else {
            res.status(400).json({
                message: "please enter proper detail.. for login..",
                status: 400
            })
        }
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "User not login..",
            status: 400
        })
    }
};

//user logout
exports.userLogout = async(req, res) => {
    try {
        req.User.tokens = req.User.tokens.filter((currele) => {
            return currele.token != req.token;

        })
        res.clearCookie("jwt");
        await req.User.save();
        res.status(200).json({
            message: "User Logout Successfully",
            status: 200,
        });
    } catch (error) {
        res.status(400).json({
            message: "user not logout..",
            status: 400
        })
    }
}

// user can update data
exports.updateUser = async(req, res) => {
    try {
        const _id = req.params.id;
        const updateData = await userData.findByIdAndUpdate(_id, req.body, { new: true });
        res.status(200).json({
            message: "Record updated",
            status: 200,
            data: updateData,
        })
    } catch (error) {
        res.status(400).json({
            message: "Record not updated..",
            status: 400
        });
    }
}


exports.userOtpSend = async(req, res) => {
    try {
        var otp = Math.floor(1000 + Math.random() * 9000);
        console.log(otp);

        email = req.body.email;
        const login = await userData.findOne({ email });

        if (!login.tokens[0]) {

            const transport = nodemailer.createTransport({
                service: "gmail",
                auth: {
                    user: "auxiliuminsura@gmail.com", // please enter your email address.
                    pass: "Vivek.dhaduk76" // please enter your email address password.
                }
            })

            const mailoption = {
                from: "auxiliuminsura@gmail.com", // please enter your email address.
                to: sendEmail.email,
                subject: "send otp in your mail",
                text: `Your otp is :- ${otp}, please don't give other person for your safety.`
            }

            transport.sendMail(mailoption);
            res.status(200).json({
                mes: "data is successfully save.. and mail is send..",
                status: 200
            })

            const token = await login.generate();
        }
        res.cookie("jwt", login.tokens[0].token)
        if (email == login.email) {
            res.status(200).json({
                message: "User successfully login...",
                status: 200
            })
        } else {
            res.status(400).json({
                message: "please enter proper detail.. for login..",
                status: 400
            })
        }
    } catch (error) {
        res.status(400).json({
            message: "User not login..",
            status: 400
        })
    }
};

exports.passwordReset = async(req, res) => {
    try {
        const user = await userData.findOne({ email: req.body.email });
        if (!user)
            return res.status(400).send("user with given email doesn't exist");

        let token = await Token.findOne({ userId: user._id });
        if (!token) {
            token = await new Token({
                userId: user._id,
                token: crypto.randomBytes(32).toString("hex"),
            }).save();
        }

        const link = `${process.env.BASE_URL}/${user._id}/${token.token}`;
        await sendEmail(user.email, "Password reset", link);

        res.send("password reset link sent to your email account");
    } catch (error) {
        res.send("An error occured");
        console.log(error);
    }
};

exports.changepassword = (async(req, res) => {
    try {


        const user = await userData.findById(req.params.userId);

        if (!user) { return res.status(400).send("invalid link or expired"); }

        const token = await Token.find({
            userId: user._id,
            token: req.params.token,
        });

        if (!token) { return res.status(400).send("Invalid link or expired"); }
        console.log(token)
        user.password = req.body.password;
        await user.save();
        await token.delete();

        res.send("password reset sucessfully.");
    } catch (error) {
        res.send("An error occured");
        console.log(error);
    }
});

otp = 269345
exports.sendEmail = async(req, res) => {
    try {
        email = req.body.email;
        const data = await userData.findOne({ email })
        const match = email === data.email
        if (match) {

            // email = req.body.email;

            const transport = nodemailer.createTransport({
                service: "gmail",
                auth: {
                    user: process.env.USER, // please enter your email address.//
                    pass: process.env.PASS // please enter your email address password.//
                }
            });

            const mailoption = {
                from: process.env.USER, // please enter your email address.//
                to: req.body.email,
                subject: "send otp in your mail",
                text: `Your otp is :- ${otp}, please don't give other person for your safety.`
            };

            transport.sendMail(mailoption);
            res.status(200).json({
                msg: "otp send"
            })
        } else {
            return res.status(status.INTERNAL_SERVER_ERROR).json(new APIResponse("Email Not Register", true, 404))
        }
    } catch (error) {
        console.log(error);
        res.status(400).json({
            msg: "otp not send"
        })
    }
};

// User Can Forgot Password //
exports.forgotPassword = async(req, res) => {
    try {
        email = req.body.email;
        otp1 = req.body.otp
        const data = await userData.findOne({ email })
        console.log(data.email);
        const com = otp1 === otp;
        console.log(com);
        if (com && email == data.email) {
            password = req.body.password;
            confirmPassword = req.body.confirmPassword;

            if (password === confirmPassword) {
                const datas = await userData.findByIdAndUpdate({ _id: data._id }, req.body, { new: true });
                res.status(200).json({
                    msg: "password update successfully"
                });
            } else {
                res.status(400).json({
                    msg: "password and config password not match"
                })
            }
        }
    } catch (error) {
        console.log(error)
        res.status(200).json({
            msg: "password not forget"
        })
    }
}
exports.viewLoginData = async(req, res) => {
    try {
        const id = req.params.id;
        const viewData = await userData.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData.email
        });


    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};