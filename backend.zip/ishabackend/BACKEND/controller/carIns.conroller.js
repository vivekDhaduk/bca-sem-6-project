const car = require("../module/carIns.modul");
const Cardata = require("../module/car.modul")

exports.carInsUserAdd = async(req, res) => {
    try {
        const insertData = new car({
            CarNumber: req.body.CarNumber,
            City: req.body.City,
            Company: req.body.Company,
            Model: req.body.Model,
            Variant: req.body.Variant,
            FuelType: req.body.FuelType,
            CarRegisterYear: req.body.CarRegisterYear
        })
        const saveData = await insertData.save();
        res.status(200).json({
            msg: "data insert",
            status: 200,
            data: saveData
        })
    } catch (error) {
        console.log(error);
        res.status(400).json({
            msg: "data not inserted",
            status: 400
        })
    }

}
exports.carInsview = async(req, res) => {
    try {

        const viewData = await car.find().sort({ "date": -1 }).limit(1);
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.carshorting = async(req, res) => {
    try {
        let CarRegisterYear = req.body.CarRegisterYear;
        const showdata = await car.findOne({ CarRegisterYear: CarRegisterYear });

        res.status(200).json({
            message: "record display",
            status: 200,
            data: showdata
        });
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
}

exports.CarCoverAcd = async (req, res) => {
    try {
      const viewData = await Cardata.find().sort({ cover: 1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };

  exports.CarCoverDcd = async (req, res) => {
    try {
      const viewData = await Cardata.find().sort({ cover: -1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };

exports.CarAcd = async (req, res) => {
  try {
    const viewData = await Cardata.find().sort({ primumamount: 1 });
    res.status(200).json({
      message: "Record  display",
      status: 200,
      data: viewData,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      message: "Something Went Wrong",
      status: 400,
    });
  }
};

exports.CarDcd = async (req, res) => {
    try {
      const viewData = await Cardata.find().sort({ primumamount: -1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };