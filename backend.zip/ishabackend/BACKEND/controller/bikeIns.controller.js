const Bike = require("../module/bikeIns.modul");
const bikedata = require("../module/bike.modul")

exports.BikeInsUserAdd = async(req, res) => {
    try {
        const insertData = new Bike({
            BikeNumber: req.body.BikeNumber,
            City: req.body.City,
            Company: req.body.Company,
            Model: req.body.Model,
            Variant: req.body.Variant,
            RegistrationYear: req.body.RegistrationYear
        })
        const saveData = await insertData.save();
        res.status(200).json({
            msg: "data insert",
            status: 200,
            data: saveData
        })
    } catch (error) {
        console.log(error);
        res.status(400).json({
            msg: "data not inserted",
            status: 400
        })
    }


}
exports.bikeInsview = async(req, res) => {
    try {

        const viewData = await Bike.find().sort({ "date": -1 }).limit(1);
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.bikeshorting = async(req, res) => {
    try {
        let RegistrationYear = req.body.RegistrationYear;
        const showdata = await Bike.findOne({ RegistrationYear: RegistrationYear });

        res.status(200).json({
            message: "record display",
            status: 200,
            data: showdata
        });
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
}

exports.bikeCoverAcd = async (req, res) => {
    try {
      const viewData = await bikedata.find().sort({ cover: 1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };

  exports.bikeCoverDcd = async (req, res) => {
    try {
      const viewData = await bikedata.find().sort({ cover: -1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };

exports.bikeAcd = async (req, res) => {
  try {
    const viewData = await bikedata.find().sort({ primumamount: 1 });
    res.status(200).json({
      message: "Record  display",
      status: 200,
      data: viewData,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      message: "Something Went Wrong",
      status: 400,
    });
  }
};

exports.bikeDcd = async (req, res) => {
    try {
      const viewData = await bikedata.find().sort({ primumamount: -1 });
      res.status(200).json({
        message: "Record  display",
        status: 200,
        data: viewData,
      });
    } catch (error) {
      console.log(error);
      res.status(400).json({
        message: "Something Went Wrong",
        status: 400,
      });
    }
  };