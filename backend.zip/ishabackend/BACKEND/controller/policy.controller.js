const helthData = require("../module/health.modul");
const bikeData = require("../module/bike.modul");
const carData = require("../module/car.modul");
const lifedata = require("../module/life.modul")

exports.viewhelthpolicy = async(req, res) => {
    try {

        const viewData = await helthData.find();
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.viewlifepolicy = async(req, res) => {
    try {

        const viewData = await lifedata.find();
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.viewcarpolicy = async(req, res) => {
    try {

        const viewData = await carData.find();
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.viewbikepolicy = async(req, res) => {
    try {

        const viewData = await bikeData.find();

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.healthcompare1 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await helthData.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.healthcompare2 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await helthData.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.healthcompare3 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await helthData.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.bikecompare1 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await bikeData.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.bikecompare2 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await bikeData.findById({ _id: id });
        console.log(viewData)

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.bikecompare3 = async(req, res) => {
    try {

        console.log("----+++++++-----");
        var id = req.params.id;
        console.log(id);
        console.log("----*************************************+++++++-----");
        const viewData = await bikeData.findById({ _id: id });
        console.log("=====>",viewData)
        res.status(200).json({
            message: "Record  display hehe",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};

exports.bikeCompare4 = async(req, res) => {
    try {
        var id = req.params.id;
        console.log(id);
        console.log("-------------------");
        const viewData = await bikeData.findById({ _id: id });
        console.log(viewData);
        res.status(200).json({
            message: "Record rohanno ",
            status: 200,
            data: viewData
        });
    } catch (error) {
        console.log(error)
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};


exports.carcompare1 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await carData.findById({ _id: id });
        console.log("car1"+ viewdata)
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        console.log(error)
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.carcompare2 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await carData.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.carcompare3 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await carData.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.lifecompare1 = async(req, res) => {
    try {
        var id = req.params.id;
        console.log(id);
        const viewData = await lifedata.findById({ _id: id });
        console.log(viewData);
        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });
    } catch (error) {
        console.log(error)
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.lifecompare2 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await lifedata.findById({ _id: id });



        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.lifecompare3 = async(req, res) => {
    try {
        var id = req.params.id;
        const viewData = await lifedata.findById({ _id: id });

        res.status(200).json({
            message: "Record  display",
            status: 200,
            data: viewData
        });


    } catch (error) {
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
};
exports.lifeDataView = async(req, res) => {
    try {
        const lookData = await lifedata.find({}).limit(10)
        // console.log("==>", lookData);
        res.status(200).json({
            message: "record display",
            status: 200,
            data: lookData
        })
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
}
exports.HealthDataView = async(req, res) => {
    try {
        const lookData = await helthData.find({}).limit(10)
        // console.log("==>", lookData);
        res.status(200).json({
            message: "record display",
            status: 200,
            data: lookData
        })
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
}
exports.CarDataView = async(req, res) => {
    try {
        const lookData = await carData.find({}).limit(10)
        // console.log("==>", lookData);
        res.status(200).json({
            message: "record display",
            status: 200,
            data: lookData
        })
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
}
exports.BikeDataView = async(req, res) => {
    try {
        const lookData = await bikeData.find({}).limit(10)
        // console.log("==>", lookData);
        res.status(200).json({
            message: "record display",
            status: 200,
            data: lookData
        })
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "Record not display",
            status: 400
        });
    }
}

exports.HealthSearch = async(req, res) => {
    try {   
        let keyword = req.body.keyword;
        // let keyword = "niva"
        
        if (keyword == " ") {
            res.status(401).json({
                message: "please write something",
                status: 401
            });
        } else {
            const data = await helthData.aggregate([{
                $match: {
                    $or: [{
                            'name':  {$regex: `${keyword}`},
                        },
                        {
                            'timeduration': {$regex: `${keyword}`},
                        },
                        {
                            'primumamount': {$regex: `${keyword}`},
                        },
                        {
                            'cover': {$regex: `${keyword}`},
                        }
                    ]
                }
            }])
            res.status(200).json({
                message: "Policy Search",
                status: 200,
                Data: data
            });
        }
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "something want wrong",
            status: 400
        })
    }
}
exports.BikeSearch = async(req, res) => {
    try {   
        let keyword = req.body.keyword;
        // let keyword = "niva"
       
        if (keyword == " ") {
            res.status(401).json({
                message: "please write something",
                status: 401
            });
        } else {
            const data = await bikeData.aggregate([{
                $match: {
                    $or: [{
                            'name': {$regex: `${keyword}`},
                        },
                        {
                            'timeduration': {$regex: `${keyword}`},
                        },
                        {
                            'primumamount': {$regex: `${keyword}`},
                        },
                        {
                            'cover': {$regex: `${keyword}`},
                        }
                    ]
                }
            }])
            res.status(200).json({
                message: "Policy Search",
                status: 200,
                Data: data
            });
        }
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "something want wrong",
            status: 400
        })
    }
}
exports.CarSearch = async(req, res) => {
    try {   
        let keyword = req.body.keyword;
        // let keyword = "niva"
        
        if (keyword == " ") {
            res.status(401).json({
                message: "please write something",
                status: 401
            });
        } else {
            const data = await carData.aggregate([{
                $match: {
                    $or: [{
                            'name': {$regex: `${keyword}`},
                        },
                        {
                            'timeduration': {$regex: `${keyword}`},
                        },
                        {
                            'primumamount': {$regex: `${keyword}`},
                        },
                        {
                            'cover': {$regex: `${keyword}`},
                        }
                    ]
                }
            }])
            res.status(200).json({
                message: "Policy Search",
                status: 200,
                Data: data
            });
        }
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "something want wrong",
            status: 400
        })
    }
}
exports.LifeSearch = async(req, res) => {
    try {   
        let keyword = req.body.keyword;
        // let keyword = "niva"
        
        if (keyword == " ") {
            res.status(401).json({
                message: "please write something",
                status: 401
            });
        } else {
            const data = await lifedata.aggregate([{
                $match: {
                    $or: [{
                            'name': {$regex: `${keyword}`},
                        },
                        {
                            'timeduration': {$regex: `${keyword}`},
                        },
                        {
                            'primumamount': {$regex: `${keyword}`},
                        },
                        {
                            'cover': {$regex: `${keyword}`},
                        }
                    ]
                }
            }])
            res.status(200).json({
                message: "Policy Search",
                status: 200,
                Data: data
            });
        }
    } catch (error) {
        console.log(error);
        res.status(400).json({
            message: "something want wrong",
            status: 400
        })
    }
}

