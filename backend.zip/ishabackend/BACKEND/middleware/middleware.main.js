const jwt = require("jsonwebtoken");
const adminData = require("../module/admin.modul");
const adviserData = require("../module/adviser.modul");
const userData = require("../module/user.modul");

const  middleSchema = async (req, res, next) => {

    try {
        const token = req.cookies.jwt;
        console.log(token)
        const verify = jwt.verify(token, process.env.ADMIN_KEY);
        const adminUser = await adminData.findOne({ _id: verify._id });
        const adviser= await adviserData.findOne({ _id: verify._id });
        const User = await userData.findOne({ _id: verify._id });
    
        req.token = token;  
        req.adminUser = adminUser;
        req.adviser = adviser;
        req.User = User;
        next();
    } catch (error) {
        res.status(400).json({
            message: "not match data..",
            status: 400
        })
    }
};

module.exports = middleSchema;