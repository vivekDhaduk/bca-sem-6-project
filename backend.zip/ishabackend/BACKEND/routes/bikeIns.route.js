const router = require("express").Router();

const {
    BikeInsUserAdd,
    bikeInsview,
    bikeshorting,
    bikeAcd,
    bikeCoverAcd,
    bikeCoverDcd,
    bikeDcd
} = require("../controller/bikeIns.controller");

router.post("/user/insert", BikeInsUserAdd);
router.get("/user/view", bikeInsview);
router.get("/user/bikeshorting", bikeshorting);

router.get("/user/acdshort",bikeAcd)
router.get("/user/bikeCoverAcd",bikeCoverAcd)
router.get("/user/bikeCoverDcd",bikeCoverDcd)
router.get("/user/dcdshort",bikeDcd)


module.exports = router