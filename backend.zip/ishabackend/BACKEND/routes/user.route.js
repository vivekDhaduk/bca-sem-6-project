const router = require("express").Router();
const auth = require("../middleware/middleware.main");
const Token = require("../module/token.modul");
const multer = require("multer");
const path = require("path");
const nodemailer = require("nodemailer");


const {
    userRegister,
    userLogin,
    userLogout,
    updateUser,
    userOtpSend,
    passwordReset,
    changepassword,
    sendEmail,
    forgotPassword,
    viewLoginData

} = require("../controller/user.controller");
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, './public/uploads')
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + "-" + file.originalname);
    }

});

const upload = multer({
    storage: storage,
    limits: { filesize: 10000 },
    fileFilter: function(req, file, cb) {
        checkFileType(file, cb);
    }

});

function checkFileType(file, cb) {
    const filetype = /jpeg|jpg|png|gif/;
    const extname = filetype.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetype.test(file.mimetype);

    if (mimetype && extname) {
        return cb(null, true);

    } else {
        cb('error:images only')
    }

}


router.post("/register", userRegister);
router.post("/login", userLogin);
router.get("/logout", auth, userLogout);
router.patch("/update/:id", updateUser);
router.post("/userOtpSend", userOtpSend);
router.post("/password-reset", passwordReset);
router.post("/:userId/:token", changepassword);
router.post("/sendmail", sendEmail);
router.post("/changepass", forgotPassword);
router.get("/viewLoginData/:id", viewLoginData);
//router.put("/forgot-password",forgotpassword)

module.exports = router;