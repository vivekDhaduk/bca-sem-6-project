'use strict'

exports.setup = (app) => {
    app.use('/api/ims/',(req, res, next) => {
        next();
    })

    var admin = require('./admin.route')
    var user = require('./user.route')
    var adviser = require('./adviser.route')
    var policy = require('./policy.route')

    app.use('/api/ims/admin', admin)
    app.use('/api/ims/user', user)
    app.use('/api/ims/adviser',adviser)
    app.use('/api/ims/policy',policy)
}

module.exports = exports