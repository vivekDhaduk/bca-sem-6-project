const router = require("express").Router();
const path = require("path");

// const uploader = require("../utils/multer")
const {

    viewhelthpolicy,
    viewlifepolicy,
    viewcarpolicy,
    viewbikepolicy,
    healthcompare1,
    healthcompare2,
    healthcompare3,
    bikecompare1,
    bikecompare2,
    bikecompare3,
    bikeCompare4,
    carcompare1,
    carcompare2,
    carcompare3,
    lifecompare1,
    lifecompare2,
    lifecompare3,
    // lifeshorting,
    lifeDataView,
    HealthDataView,
    CarDataView,
    BikeDataView,
    HealthSearch,
    BikeSearch,
    CarSearch,
    LifeSearch


} = require("../controller/policy.controller");

router.get("/viewhelth", viewhelthpolicy);
router.get("/viewlife", viewlifepolicy);
router.get("/viewcar", viewcarpolicy);
router.get("/viewbike", viewbikepolicy);
router.get("/healthcompare1/:id", healthcompare1);
router.get("/healthcompare2/:id", healthcompare2);
router.get("/healthcompare3/:id", healthcompare3);
router.get("/bikecompare1/:id", bikecompare1);
router.get("/bikecompare2/:id", bikecompare2);
router.get("/bikecompare3/:id", bikecompare3);
router.get("/bikecompare4/:id", bikeCompare4);
router.get("/carcompare1/:id", carcompare1);
router.get("/carcompare2/:id", carcompare2);
router.get("/carcompare3/:id", carcompare3);
router.get("/lifecompare1/:id", lifecompare1);
router.get("/lifecompare2/:id", lifecompare2);
router.get("/lifecompare3/:id", lifecompare3);
// router.get("/lifeshorting", lifeshorting);
router.get("/lifeDataView", lifeDataView);
router.get("/HealthDataView",HealthDataView);
router.get("/CarDataView",CarDataView);
router.get("/BikeDataView",BikeDataView);
router.post("/HealthSearch",HealthSearch);
router.post("/BikeSearch",BikeSearch);
router.post("/CarSearch",CarSearch);
router.post("/LifeSearch",LifeSearch)

module.exports = router;