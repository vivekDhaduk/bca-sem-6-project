const router = require("express").Router();
const main = require("../middleware/middleware.main");

const {
    adminLogin,
    adminLogout,
    viewUser,
    insertUser,
    deleteUser,
    updateUser,
} = require("../controller/admin.controller");

router.post("/login", adminLogin);
router.get("/logout", main, adminLogout);
router.get("/view", viewUser);
router.post("/insert", insertUser);
router.delete("/delete/:id", deleteUser);
router.patch("/update/:id", updateUser);

module.exports = router;