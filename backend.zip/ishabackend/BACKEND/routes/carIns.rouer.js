const router = require("express").Router();

const {
    carInsUserAdd,
    carInsview,
    carshorting,
    CarAcd,
    CarDcd,
    CarCoverAcd,
    CarCoverDcd
} = require("../controller/carIns.conroller")

router.post("/user/insert", carInsUserAdd);
router.get("/user/view", carInsview);
router.get("/user/carshorting", carshorting);

router.get("/user/acdshort",CarAcd)
router.get("/user/CarhCoverAcd",CarCoverAcd)
router.get("/user/CarhCoverDcd",CarCoverDcd)
router.get("/user/dcdshort",CarDcd)

module.exports = router;