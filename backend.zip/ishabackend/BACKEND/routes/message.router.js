const router = require("express").Router();


const {
    MessIns
} = require("../controller/message.controller")

router.post("/insert", MessIns)
module.exports = router;