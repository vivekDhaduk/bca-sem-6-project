const router = require("express").Router();

const {
    HealthInsUserAdd,
    HeathInsview,
    healthshorting,
    healthAcd,
    healthDcd,
    healthCoverDcd,
    healthCoverAcd
} = require("../controller/HealthIns.controller")

router.post("/user/insert", HealthInsUserAdd);
router.get("/user/view", HeathInsview)
router.get("/user/healthshorting", healthshorting)

router.get("/user/acdshort",healthAcd)
router.get("/user/healthCoverAcd",healthCoverAcd)
router.get("/user/healthCoverDcd",healthCoverDcd)
router.get("/user/dcdshort",healthDcd)

module.exports = router