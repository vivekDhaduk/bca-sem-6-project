const router = require("express").Router();
const auth = require("../middleware/middleware.main");
const multer = require("multer");
const path = require("path");

const {
    adviserRegister,
    viewadvisor,
    viewadvisorbyid,
    viewhelthadvisor,
    viewlifeadvisor,
    viewcaradvisor,
    viewbikeadvisor,
    adviserLogin,
    adviserLogout,
    updateadviser 
} = require("../controller/adviser.controller");

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads')
    },
    filename: (req, file, cb) => {
        cb(null,file.fieldname + '-' + Date.now() +"-"+file.originalname);
    }
  
  });
  
  const upload = multer({
    storage: storage,
    limits: { filesize: 10000 },
    fileFilter: function (req, file, cb) {
        checkFileType(file, cb);
    }
  
  });
  function checkFileType(file, cb) {
    const filetype = /jpeg|jpg|png|gif/;
    const extname = filetype.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetype.test(file.mimetype);
  
    if (mimetype && extname) {
        return cb(null, true);
  
    }
    else {
        cb('error:images only')
    }
  
  }
  
  
  
  
  


router.post("/register", upload.single('image'), adviserRegister);
router.get("/viewadvisorbyid/:id",viewadvisorbyid);
router.get("/viewadvisor", viewadvisor);
router.get("/viewhelthadvisor",viewhelthadvisor);
router.get("/viewlifeadvisor",viewlifeadvisor);
router.get("/viewcaradvisor",viewcaradvisor);
router.get("/viewbikeadvisor",viewbikeadvisor);
router.post("/login",adviserLogin);
router.get("/logout", auth, adviserLogout);
router.patch("/update/:id", updateadviser );


module.exports = router;