const router = require("express").Router();

const {
    LifeInsUserAdd,
    lifeInsview,
    lifeshorting,
    lifeAcd,
    lifeDcd,
    lifeCoverAcd,
    lifeCoverDcd

} = require("../controller/LifeIns.controller")

router.post("/user/insert", LifeInsUserAdd);
router.get("/user/view", lifeInsview)
router.get("/user/lifeshorting", lifeshorting);

router.get("/user/acdshort",lifeAcd)
router.get("/user/lifeCoverAcd",lifeCoverAcd)
router.get("/user/lifeCoverDcd",lifeCoverDcd)
router.get("/user/dcdshort",lifeDcd)


module.exports = router