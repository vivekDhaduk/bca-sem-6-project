const mongoose = require("mongoose");

const LifeSchema = new mongoose.Schema({
    gender: {
        type: String,

    },
    fullname: {
        type: String,

    },
    age: {
        type: String,

    },
    dateofbirth: {
        type: String,

    },
    city: {
        type: String,

    },
    annualincome: {
        type: String,

    },
    nominee: {
        type: String,

    },
    date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("Life", LifeSchema);