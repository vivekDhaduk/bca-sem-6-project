const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");

const userSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    email: {
        type: String,    
    },
    number: {
        type: String,
    },
    gender:{
        type:String,
    },
    age:{
        type:Number,
    },
    panno:{
        type:String,

    },
    password:{
        type:String
    },
    //image: {
    //     type: String,
        
    // },
    resetLink:{
        data:String,
        default:''
    },
     tokens: [
        {
            token: {
                type: String
            }
        }
    ]
},{
   timestamps:true 
},{ collection: "user" }
);

userSchema.methods.generate = async function(){
    try {
        const token = jwt.sign({ _id: this._id.toString() }, process.env.ADMIN_KEY);
        this.tokens = this.tokens.concat({ token: token });
        await this.save();
        return token;

    } catch (error) {
        res.status(400).json({
            message: "token not generated..",
            status: 400
        })
    }
}

module.exports = mongoose.model("user", userSchema);