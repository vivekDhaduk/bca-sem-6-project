const mongoose = require("mongoose");



const CarSchema = new mongoose.Schema({
    CarNumber: {
        type: String,
        
    },
    City: {
        type: String,
        
    },
    Company: {
        type: String,
        
    },
    Model: {
        type: String,
      
    },
    Variant: {
        type: String,
        
    },
    FuelType: {
        type: String,
        
    },
    CarRegisterYear: {
        type: String,
        
    },
    date:{
        type:Date,
        default: Date.now
    }

});

module.exports = mongoose.model("car", CarSchema);