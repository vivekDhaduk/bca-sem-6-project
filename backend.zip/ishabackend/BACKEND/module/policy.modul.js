const mongoose = require("mongoose");

const policySchema = new mongoose.Schema({
    policyname: {
        type: String
    },
    shortdiscription:{
        type:String
    },
    primumamount: {
        type: String
    },
    timeduration: {
        type: String
    },
    paymenttype:{
        type:String
    },
    termsconditions:{
        type:String
    }
  
});

policySchema.virtual('likeCount', {
    ref: 'Like',
    localField: '_id',
    foreignField: 'policyId',
    count: true
});

policySchema.virtual('likes', {
    ref: 'Like',
    localField: '_id',
    foreignField: 'policyId',
});

module.exports = mongoose.model("policydata", policySchema);