const mongoose = require("mongoose");

const BikeSchema = new mongoose.Schema({
    BikeNumber: {
        type: String,
    },
    City: {
        type: String,
    },
    Company: {
        type: String,
    },
    Model: {
        type: String,
    },
    Variant: {
        type: String,
    },
    RegistrationYear: {
        type: String,
    },
    date: {
        type: Date,
        default: Date.now
    }

});

module.exports = mongoose.model("bike", BikeSchema);