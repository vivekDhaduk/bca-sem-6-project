const mongoose = require("mongoose");

const HealthSchema = new mongoose.Schema({
    gender: {
        type: String,
    },
    fullname: {
        type: String,
    },
    dateofbirth: {
        type: String,
    },
    age: {
        type: String,
    },
    city: {
        type: String,
    },
    healthproblem: {
        type: String,
    },
    annualincome: {
        type: String,
    },
    date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("Health", HealthSchema);