const express = require("express");
const app = express();
const http = require("http");
const cors = require('cors');
const { Server } = require("socket.io");
app.use(cors());
const cookieParser = require("cookie-parser");
const nodemailer = require("nodemailer");
require("dotenv").config();
require("./db/conn");
const admin = require("./module/admin.modul");
const adviser = require("./module/adviser.modul");
const policy = require("./module/policy.modul");

const port = process.env.port;

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"],
  },
});

io.on("connection", (socket) => {
  console.log(`User Connected: ${socket.id}`);

  socket.on("join_room", (data) => {
    socket.join(data);
    console.log(`User with ID: ${socket.id} joined room: ${data}`);
  });

  socket.on("send_message", (data) => {
    socket.to(data.room).emit("receive_message", data);
  });

  socket.on("disconnect", () => {
    console.log("User Disconnected", socket.id);
  });
});





app.use(express.json());


app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
//const routes = require('./routes');
//routes.setup(app);

const userInsRoute = require("./routes/user.route");
app.use("/userIns", userInsRoute);

const advisorRoute = require("./routes/adviser.route");
app.use("/advisor",advisorRoute)


const carInsRoute = require("./routes/carIns.rouer");
app.use("/carIns", carInsRoute);

const BikeInsRoute = require("./routes/bikeIns.route");
app.use("/BikeIns", BikeInsRoute);

const LifeInsRoute = require("./routes/LifeIns.route");
app.use("/LifeIns", LifeInsRoute);

const HealthInsRoute = require("./routes/HealthIns.router");
app.use("/HealthIns", HealthInsRoute);

const policyRoute = require("./routes/policy.route");
app.use("/policy", policyRoute);

const MessageRoute = require("./routes/message.router");
app.use("/message",MessageRoute)

app.listen(port, () => {
    console.log(`Your Project Is Running On ${port} port. `);
});


//module.exports = app

